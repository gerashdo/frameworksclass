from django.apps import AppConfig


class TablaMultiplicarConfig(AppConfig):
    name = 'tabla_multiplicar'
